# threeVP.js

#### JavaScript package ####

Just a simple require.js package for three.js.

core.js

- require.js, text, less
- lodash.js, jquery, backbone.js, 
- three.js, ThreeCSG, OrbitControl,
- stats.js, dat.gui, tween.js,
- async.js 

viewport.js

- OrbitControls.js

